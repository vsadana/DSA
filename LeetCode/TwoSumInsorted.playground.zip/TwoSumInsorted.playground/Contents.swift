import UIKit

var greeting = "Hello, playground"
/**
 Input: numbers = [2,7,11,15], target = 9
 Output: [1,2]
 */

func twoSum(_ numbers: [Int], _ target: Int) -> [Int] {
    var dict = [Int : Int]()
    for (j, i) in numbers.enumerated() {
        if dict[target - i] != nil {
            return [dict[target - i]!, j + 1]
        } else {
            dict[i] =  j + 1 // [2: 7]
        }
    }
    return []
}


twoSum([2,3,4], 6)
